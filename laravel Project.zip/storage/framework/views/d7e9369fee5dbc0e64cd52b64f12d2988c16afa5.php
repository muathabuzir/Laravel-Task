<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Save Result')); ?></div>
                <div class="card-body">
                    <h5 class="mb-0"><a class="text-primary" href="<?php echo e($saved_result->link); ?>"><?php echo e($saved_result->title); ?></a></h5>
                    <h6 class="mb-0"><a class="text-success" href="<?php echo e($saved_result->link); ?>"><?php echo e($saved_result->link); ?></a></h6>
                    <div class="text-muted"><?php echo e($saved_result->desc); ?></div>
                    <hr />
                    <div class="row">
                        <div class="col-6 text-black-50">
                            Create: <?php echo e($saved_result->created_at); ?>

                        </div>
                        <div class="col-6 text-black-50 text-right">
                            Last Update: <?php echo e($saved_result->updated_at); ?>

                        </div>
                    </div>
                    <hr />
                    <h6 class="mt-2 mb-0"><?php echo e(__('Comment')); ?></h6>
                    <div class="text-muted"><?php echo e($saved_result->comment); ?></div>
                    <hr />
                    <a class="btn btn-light" href="/saved_results"><?php echo e(__('Back')); ?></a>
                    <a class="btn btn-primary" href="/saved_results/<?php echo e($saved_result->id); ?>/edit"><?php echo e(__('Edit')); ?></a>
                    <button onclick="(confirm('are you sure to delete this item?') ? $('#delete_form').submit() : '');" type="button" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                    <form id="delete_form" class="w-0" action="/saved_results/<?php echo e($saved_result->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/searchEngine/resources/views/SavedResults/show.blade.php ENDPATH**/ ?>