<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Save Result</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <form class="needs-validation col-12" novalidate method="GET" action="/home">
                            <?php echo csrf_field(); ?>
                            <div class="input-group">
                                <input type="text" name="search" value="<?php echo e(old('search')); ?>" class="form-control" id="search" placeholder="Search" aria-describedby="inputGroupPrepend2" required>
                                <div class="input-group-append">
                                    <button class="input-group-text" type="submit" id="inputGroupPrepend2">Search</button>
                                </div>
                            </div>
                            <?php if ($errors->has('search')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('search'); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </form>
                    </div>
                    <hr />
                    <?php if(!count($result)): ?>
                    <div class="alert alert-danger">Opps No Data</div>
                    <?php else: ?>
                    <?php if ($errors->has('checked')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('checked'); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <form method="post" action="/home">
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3 border border-info rounded p-2">
                            <h4 class="mb-0"><input title="save" type="checkbox" name="checked[<?php echo e($k); ?>]" value="<?php echo e($k); ?>" /> <a class="text-primary" href="<?php echo e($res->link); ?>"><?php echo e($res->title); ?></a></h4>
                            <h5 class="mb-0"><a class="text-success" href="<?php echo e($res->link); ?>"><?php echo e($res->link); ?></a></h5>
                            <div class="text-muted"><?php echo e($res->snippet); ?></div>
                            <input type="hidden" name="value[<?php echo e($k); ?>]" value="<?php echo e(json_encode($res)); ?>"  />
                            <textarea title="comment" placeholder="Set Comment Here..." class="w-100 p-1" name="comment[<?php echo e($k); ?>]"><?php echo e(old('comment.'.$k)); ?></textarea>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn btn-primary" type="submit">Save</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/searchEngine/resources/views/SaveResults/index.blade.php ENDPATH**/ ?>