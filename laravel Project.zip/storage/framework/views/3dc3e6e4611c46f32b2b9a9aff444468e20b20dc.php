<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Save Result')); ?></div>
                <div class="card-body">
                    <?php if(!count($saved_results)): ?>
                    <div class="alert alert-warning"><?php echo e(__('Oops there is no Saved Results')); ?></div>  
                    <?php else: ?>
                    <table class="table table-hover w-100">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Comment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $saved_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($saved['id']); ?></td>
                                <td><a href="<?php echo e($saved['link']); ?>"><?php echo e($saved['title']); ?></a></td>
                                <td><?php echo e(( mb_strlen($saved['desc']) > 50 ? mb_substr($saved['desc'], 0, 25).'...' :$saved['desc'] )); ?></td>
                                <td><?php echo e(( mb_strlen($saved['comment']) > 50 ? mb_substr($saved['comment'], 0, 25).'...' :$saved['comment'] )); ?></td>
                                <td><a href="saved_results/<?php echo e($saved['id']); ?>"><?php echo e(__('View')); ?></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/searchEngine/resources/views/SavedResults/index.blade.php ENDPATH**/ ?>